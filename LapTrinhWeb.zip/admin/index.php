<?php
include_once 'inc/header.php';
?>
<div class="titleRight path">
  <a href="index.php">home</a> >
</div>
</div>
</div>
<?php
include_once 'inc/footer.php';
?>

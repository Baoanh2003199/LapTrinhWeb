<?php
  define("DB_HOST","sql12.freemysqlhosting.net");
  define("DB_USER","sql12315898");
  define("DB_PASS","stzpj7wHju");
  define("DB_NAME","sql12315898");
?>
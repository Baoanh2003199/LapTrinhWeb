-Server: sql12.freemysqlhosting.net
-Database Name: sql12315898
-Username: sql12315898
-Password: stzpj7wHju
slider image size :640x300